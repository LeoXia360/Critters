package assignment4;
/* CRITTERS <MyClass.java>
 * EE422C Project 4 submission by
 * Replace <...> with your actual data.
 * Leo Xia
 * LX939
 * 16450
 * Kevin Wong
 * kw25779
 * 16475
 * Slip days used: <0>
 * Fall 2016
 */
