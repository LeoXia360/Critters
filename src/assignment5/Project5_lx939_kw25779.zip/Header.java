/* CRITTERS GUI <MyClass.java>
 * EE422C Project 4b submission by
 * Replace <...> with your actual data.
 * <Kevin Wong>
 * <kw25779>
 * <16475>
 * <Leo Xia>
 * <lx939>
 * <16450>
 * Slip days used: <0>
 * Fall 2016
 */

/*
   Describe here known bugs or issues in this file. If your issue spans multiple
   files, or you are not sure about details, add comments to the README.txt file.
 */
package assignment5;
